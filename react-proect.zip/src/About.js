function About(props) {
    return (
          <a href="#about" className="about">About</a>             
        )
}

export default About