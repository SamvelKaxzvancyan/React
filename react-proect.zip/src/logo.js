function Logo(props) {
    return (
          <a href="#logo" className="logo">Bmw<span>.</span></a>             
        )
}

export default Logo