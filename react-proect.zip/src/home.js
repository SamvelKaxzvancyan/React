function Home(props) {
    return (
          <a href="#home" className="home">Home</a>             
        )
}

export default Home