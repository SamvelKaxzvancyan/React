function Team(props) {
    return (
          <a href="#team" className="team">Team</a>             
        )
}

export default Team