function Services(props) {
    return (
          <a href="#services" className="services">Services</a>             
        )
}

export default Services