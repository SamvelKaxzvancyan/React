function Login(props) {
    return (
        <a href="#login" className="login">Login</a> 
        )
}

export default Login