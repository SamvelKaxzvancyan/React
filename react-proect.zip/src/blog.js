function Blog(props) {
    return (
          <a href="#blog" className="blog">Blog</a>             
        )
}

export default Blog