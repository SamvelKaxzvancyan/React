import logo from './logo.svg';
import './App.css';
import Logo from './logo'; 
import './main.css'
import Home from './home';
import About from './About';
import Blog from './blog';
import Services from './services';
import Team from './team';
import Contact from './contact';
import Login from './Log';
import Container1 from './container1';

function App() {
  return (
    <div>  
          <Logo/>
          <Home/>
          <About/>
          <Blog/>
          <Services/>
          <Team/>
          <Contact/>
          <Login/>
          <Container1/>
    </div>
  );
}

export default App;
