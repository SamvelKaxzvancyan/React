function Contact(props) {
    return (
          <a href="#contact" className="contact">Contact</a>             
        )
}

export default Contact